import { ColorFadePipe } from './color-fade.pipe';

describe('ColorFadePipe', () => {
  it('create an instance', () => {
    const pipe = new ColorFadePipe();
    expect(pipe).toBeTruthy();
  });
});
