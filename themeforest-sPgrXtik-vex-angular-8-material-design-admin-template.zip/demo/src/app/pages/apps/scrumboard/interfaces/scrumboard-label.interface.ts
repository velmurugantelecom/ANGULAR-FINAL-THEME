export interface ScrumboardLabel {
  label: string;
  background: string;
  color: string;
}
