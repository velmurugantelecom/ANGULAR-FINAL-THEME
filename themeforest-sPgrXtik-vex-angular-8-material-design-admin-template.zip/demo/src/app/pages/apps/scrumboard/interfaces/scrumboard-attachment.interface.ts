export interface ScrumboardAttachment {
  id: number;
  name: string;
  extension: string;
  path: string;
  size: string;
}

