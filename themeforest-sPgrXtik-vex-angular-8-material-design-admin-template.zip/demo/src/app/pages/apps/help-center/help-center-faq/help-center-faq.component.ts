import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'vex-help-center-faq',
  templateUrl: './help-center-faq.component.html',
  styleUrls: ['./help-center-faq.component.scss']
})
export class HelpCenterFaqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
